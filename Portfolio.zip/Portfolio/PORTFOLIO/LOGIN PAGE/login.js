
  if (performance.navigation.type === 1) {
    // If the page was reloaded, go back to the main page
    window.location.href = "/PORTFOLIO/index.html";
  }

